// Making a map and tiles
// Setting a higher initial zoom to make effect more obvious
      
        